Config = {}

Config.Location = {
    fortwallace = {
        coords = vector3(351.2592, 1483.0507, 179.5449),
        radius = 50
    },
    valentine = {
        coords = vector3(-295.86, 790.62, 118.46),
        radius = 50
    },
}